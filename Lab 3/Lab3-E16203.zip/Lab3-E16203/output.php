<!DOCTYPE html>
<html>
<head>
	<style>
			body {
	             padding:20px;
                 }
        </style>
	<div style="width:650px;height:650px;border:10px solid black"> 
   <h1> Your Information System </h1>
</head>
<body>

<?php
	$firstName = $_POST['F_name'];
	$lastName = $_POST['L_name'];
	$colour = $_POST['colour'];
	$size = $_POST['size'];

    echo "Thank you,". $firstName. " for your purchase from our website <br /><br />";
    echo "your item colour is : ". $colour. " & T-shirt size: ". $size. "<br /><br />";
    echo "Selected items/item are : <br /><br />";
    if (!empty($_POST['cap']) && !empty($_POST['wristband'])){
	  echo "* Cap  <br />" ;
	  echo "* Wristband <br /><br />";
	}
    else if (!empty($_POST['cap'])){
	  echo "* Cap <br /><br />" ;
	}
	else if (!empty($_POST['wristband'])){
	  echo "* Wristband <br /><br />";
	}
	
	echo "Your items will be sent to :<br /><br />";
	echo $firstName. " ". $lastName.",<br />";
	echo $_POST['Address1'];
	if (!empty($_POST['Address2'])){
		echo ",<br />". $_POST['Address2'];
	}
	if (!empty($_POST['Address3'])){
		echo ",<br />". $_POST['Address3'];
	}
	echo ".<br /><br />";
    
    if(!empty($_POST['comments'])){
	echo "Thank you for submitting your comments.We appreciate it.You said: <br /><br />";
	echo $_POST['comments'];
    }
?>

</body>
</html>